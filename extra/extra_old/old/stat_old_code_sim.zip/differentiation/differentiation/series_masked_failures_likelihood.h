//#ifndef _SERIES_MASKED_FAILURE_LIKELIHOOD_H__
//#define _SERIES_MASKED_FAILURE_LIKELIHOOD_H__
//
//#include "masked_failure_likelihood.h"
//#include "series_distribution.h"
//#include <alex/math.h>
//
//namespace alex { namespace statistics { namespace masked_failures
//{
//    class SeriesMaskedFailureLikelihood : public MaskedFailureLikelihood
//    {
//    public:
//        SeriesMaskedFailureLikelihood(alex::statistics::distribution::SeriesDistribution d) : _dist(d) {};
//
//        // log-likelihood function
//        std::function<double(const column_vector&)> log_likelihood() const
//        {
//            auto like = [ds = _dist.get_distributions(), samp = get_sample().to_vector()](const alex::math::column_vector& v) -> double
//            {
//                for (const auto& o : samp)
//                {
//                    for (auto j : o.candidates())
//                    {
//                        ds[j]->get_pdf()(v);
//                    }
//                }
//            }
//        };
//
//        int parameter_count() const
//        {
//            return _dist.parameter_count();
//        };
//
//    private:
//        alex::statistics::distribution::SeriesDistribution _dist;
//    };
//}}}
//
//#endif