#ifndef __OPTIMIZATION_H__
#define __OPTIMIZATION_H__

#include <algorithm>
#include "penalty_method_factory.h"
#include <alex/math.h>
#include <alex/Entropy.h>
#include <alex/differentiation.h>
#include <dlib/optimization.h>

namespace alex { namespace math { namespace optimization
{
    /**
    * interface
    */
    template <class E>
    std::vector<std::pair<double, column_vector>> find_max_brute_force_interval(
        std::function<double(const column_vector&)> max_func,
        int size,
        alex::statistics::Entropy<double, E>& entropy,
        const std::pair<double, double>& interval,
        int iterations,
        int top_k);

    template <class E>
    std::pair<double, column_vector> find_max(
        std::function<double(const column_vector&)> max_func,
        int size,
        alex::statistics::Entropy<double, E>& entropy,
        const std::pair<double, double>& interval,
        double alpha,
        double eps);

    template <class E>
    std::pair<double, column_vector> find_max(
        std::function<double(const column_vector&)> max_func,
        std::function<column_vector(const column_vector&)> grad_max_func,
        int size,
        alex::statistics::Entropy<double, E>& entropy,
        const std::pair<double, double>& interval,
        double alpha,
        double eps);

    std::pair<double, column_vector> find_max_gradient_ascent_project(
        std::function<double(const column_vector&)> max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double alpha,
        double eps);

    std::pair<double, column_vector> find_max_gradient_ascent_project(
        std::function<double(const column_vector&)> max_func,
        std::function<column_vector(const column_vector&)> grad_max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double alpha,
        double eps);

    std::pair<double, column_vector> find_max_gradient_ascent_penalty(
        std::function<double(const column_vector&)> max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double alpha,
        double eps);

    std::pair<double, column_vector> find_max_bfgs(
        std::function<double(const column_vector&)> max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double eps);

    std::pair<double, column_vector> find_max_bfgs(
        std::function<double(const column_vector&)> max_func,
        std::function<column_vector(const column_vector&)> grad_max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double eps);

    /**
     * implementation
     */
    template <class E>
    std::pair<double, column_vector> find_max(
        std::function<double(const column_vector&)> max_func,
        std::function<column_vector(const column_vector&)> grad_max_func,
        int size,
        alex::statistics::Entropy<double, E>& entropy,
        const std::pair<double, double>& interval,
        double alpha,
        double eps)
    {
        const int RANDOM_STARTING_PT_ITERATIONS = 10000;
        const int RANDOM_STARTING_PTS = 5;


        const auto& random_pts = find_max_brute_force_interval(max_func, size, entropy, interval, RANDOM_STARTING_PT_ITERATIONS, RANDOM_STARTING_PTS);

        auto best_sol = random_pts.front();
        for (const auto& pt : random_pts)
        {
            try
            {
                const auto& candidate = find_max_gradient_ascent_project(max_func, grad_max_func, pt.second, interval, alpha, eps);
                if (candidate.first > best_sol.first)
                {
                    best_sol = candidate;
                    std::cout << candidate.first << std::endl;
                }
            }
            catch (...) {};

        }
        /*
        for (const auto& pt : random_pts)
        {
            try
            {
                const auto& candidate = find_max_gradient_ascent_penalty(max_func, pt.second, interval, alpha, eps);
                if (candidate.first > best_sol.first)
                {
                    best_sol = candidate;
                    std::cout << candidate.first << std::endl;
                }
            }
            catch (...) {};
        }
        */
        for (const auto& pt : random_pts)
        {
            try
            {
                const auto& candidate = find_max_bfgs(max_func, grad_max_func, pt.second, interval, eps);
                if (candidate.first > best_sol.first)
                {
                    best_sol = candidate;
                    std::cout << candidate.first << std::endl;
                }
            }
            catch (...) {};
        }

        return best_sol;
    }


    template <class E>
    std::pair<double, column_vector> find_max(
        std::function<double(const column_vector&)> max_func,
        int size,
        alex::statistics::Entropy<double, E>& entropy,
        const std::pair<double, double>& interval,
        double alpha,
        double eps)
    {
        return find_max(
            max_func,
            differentiation::gradient(max_func, size, alpha),
            size,
            entropy,
            interval,
            alpha,
            eps);
    };

    std::pair<double, column_vector> find_max_gradient_ascent_project(
        std::function<double(const column_vector&)> max_func,
        std::function<column_vector(const column_vector&)> grad_max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double alpha,
        double eps)
    {
        eps *= eps;
        static const int MAX_TRIALS = 10000;

        for (int i = 0; i < MAX_TRIALS; ++i)
        {
            column_vector next = start + alpha * grad_max_func(start);
            for (auto& x : next)
            {
                if (x < interval.first)
                    x = interval.first;
                else if (x > interval.second)
                    x = interval.second;
            }

            auto delta = next - start;
            if (dlib::dot(delta, delta) <= eps)
                return std::make_pair(max_func(next), next);

            start = std::move(next);
        }

        return std::make_pair(max_func(start), start);
    };

    std::pair<double, column_vector> find_max_gradient_ascent_project(
        std::function<double(const column_vector&)> max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double alpha,
        double eps)
    {
        return find_max_gradient_ascent_project(
            max_func,
            differentiation::gradient(max_func, start.size()),
            start,
            interval,
            alpha,
            eps);
    };

    std::pair<double, column_vector> find_max_gradient_ascent_penalty(
        std::function<double(const column_vector&)> max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double alpha,
        double eps)
    {
        auto pen_func = PenaltyMethodFactory::get_penalty_method_penalty_interval(
            max_func,
            start.size(),
            interval);

        return find_max_gradient_ascent_project(
            pen_func,
            differentiation::gradient(pen_func, start.size()),
            start,
            interval,
            alpha,
            eps);
    };

    template <class E>
    std::vector<std::pair<double, column_vector>> find_max_brute_force_interval(
        std::function<double(const column_vector&)> max_func,
        int size,
        alex::statistics::Entropy<double, E>& entropy,
        const std::pair<double, double>& interval,
        int iterations,
        int top_k)
    {
        if (iterations < 1 || top_k < 1 || size < 1 ||
            iterations < top_k || interval.first > interval.second)
        {
            throw std::invalid_argument("Invalid Argument");
        }

        column_vector v(size);
        std::vector<std::pair<double, column_vector>> min_heap;
        min_heap.reserve(top_k);

        for (int i = 0; i < top_k; ++i)
        {
            for (auto& x : v)
                x = entropy.getReal(interval.first, interval.second);
            min_heap.push_back(std::make_pair(max_func(v), v));
        }

        auto min_heap_fn = [](
            const std::pair<double, column_vector>& x1,
            const std::pair<double, column_vector>& x2)
        {
            return x1.first > x2.first;
        };

        std::make_heap(min_heap.begin(), min_heap.end(), min_heap_fn);
        for (int i = 0; i < iterations - top_k; ++i)
        {
            for (auto& x : v)
                x = entropy.getReal(interval.first, interval.second);

            auto f_v = max_func(v);

            if (min_heap.front().first < f_v)
            {
                std::pop_heap(min_heap.begin(), min_heap.end(), min_heap_fn);
                min_heap.pop_back();
                min_heap.push_back(std::make_pair(f_v, v));
                std::push_heap(min_heap.begin(), min_heap.end(), min_heap_fn);
            }
        }

        std::sort(min_heap.begin(), min_heap.end(), [](
            const std::pair<double, column_vector>& x1,
            const std::pair<double, column_vector>& x2)
        {
            return x1.first > x2.first;
        });

        return min_heap;
    }

    std::pair<double, column_vector> find_max_bfgs(
        std::function<double(const column_vector&)> max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double eps)
    {
        return find_max_bfgs(
            max_func,
            dlib::derivative(max_func),
            start,
            interval,
            eps);
    };

    std::pair<double, column_vector> find_max_bfgs(
        std::function<double(const column_vector&)> max_func,
        std::function<column_vector(const column_vector&)> grad_max_func,
        column_vector start,
        const std::pair<double, double>& interval,
        double eps)
    {
        column_vector low(start.size());
        column_vector high(start.size());
        for (auto& x : low)
            x = interval.first;
        for (auto& x : high)
            x = interval.second;

        dlib::find_max_box_constrained(
            dlib::bfgs_search_strategy(),                   // use BFGS search algorithm; find hessian and try dlib::newton_search_strategy() next
            dlib::objective_delta_stop_strategy(eps),       // stop when the change is less than 1e-7
            max_func,
            grad_max_func,                                  // gradient
            start,
            low,
            high);

        for (auto& x : start)
        {
            if (x < interval.first)
                x = interval.first;
            else if (x > interval.second)
                x = interval.second;
        }

        return std::make_pair(max_func(start), start);
    };
}}}

#endif