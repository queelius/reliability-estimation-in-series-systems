#ifndef _SERIES_EXPONENTIAL_MASKED_FAILURE_LIKELIHOOD_H__
#define _SERIES_EXPONENTIAL_MASKED_FAILURE_LIKELIHOOD_H__

//#include "series_masked_failures_likelihood.h"
#include <stdexcept>
#include <functional>
#include <vector>
#include <utility>
#include "masked_failures.h"
#include "masked_failures_likelihood.h"
#include <alex/math.h>


namespace alex { namespace statistics { namespace masked_failures
{
    class ExponentialSeriesMaskedFailuresLikelihood : public MaskedFailuresLikelihood
    {
    public:
        ExponentialSeriesMaskedFailuresLikelihood(int comp_count) : _comp_count(comp_count)
        {
            if (_comp_count < 1)
                throw std::invalid_argument("comp_count must be greater than or equal to 1");
        };

        void load_sample(const MaskedFailuresSample& sample)
        {
            for (const auto& o : sample.to_vector())
                for (const auto& node : o.candidates())
                    if (node > _comp_count || node < 0)
                        throw std::invalid_argument("Invalid Node");

            _t_sum = -sample.sum_time();
            MaskedFailuresLikelihood::load_sample(sample);
        };

        // log-likelihood function with respect to the lambdas
        std::function<double(const alex::math::column_vector&)> log_likelihood() const
        {
            return[t_sum = _t_sum, samp = get_sample().to_vector(), comp_count = _comp_count](const alex::math::column_vector& lambda) -> double
            {
                if (comp_count != lambda.size())
                    throw std::invalid_argument("Invalid Argument");

                double result = 0;

                // sum(lambda)
                for (auto l : lambda)
                    result += lambda;

                // -sum(lambda) * sum(T)
                result *= t_sum;

                for (const auto& o : samp)
                {
                    double s = 0;
                    for (auto comp : o.candidates())
                        s += lambda(comp);
                    result += std::log(s);
                }

                return result;
            };
        };

        // gradient of log-likelihood
        std::function<alex::math::column_vector(const alex::math::column_vector&)> score() const
        {
            return[t_sum = _t_sum, samp = get_sample().to_vector(), comp_count = _comp_count]
                (const alex::math::column_vector& lambda) -> alex::math::column_vector
            {
                if (comp_count != lambda.size())
                    throw std::invalid_argument("Invalid Argument");

                alex::math::column_vector result(comp_count);
                for (int i = 0; i < comp_count; ++i)
                {
                    result(i) = t_sum;

                    for (const auto& o : samp)
                    {
                        if (o.is_candidate(i))
                        {
                            double s = 0;
                            for (auto comp : o.candidates())
                                s += lambda(comp);
                            result(i) += 1. / s;
                        }
                    }
                }
            };
        };

        int parameter_count() const { return _comp_count; };

        std::pair<double, alex::math::column_vector> find_mle() const
        {
            try
            {
                auto r = std::make_pair(0., -get_sample().size() / _t_sum);
                auto entropy = alex::statistics::Entropy<>();
                return alex::math::optimization::find_max(
                    log_likelihood(), score(), parameter_count(), entropy, r, 1e-3, 1e-7);
            }
            catch (const std::exception& e)
            {
                std::cout << e.what() << std::endl;
            };
        };

        std::function<info_matrix(const alex::math::column_vector&)> observed_info() const
        {
            return[comp_count = _comp_count, samp = get_sample()](const alex::math::column_vector& lambda)
            {
                info_matrix J(comp_count, comp_count);
                for (int i = 0; i < comp_count; ++i)
                {
                    for (int j = 0; j <= i; ++j)
                    {
                        for (const auto& o : samp.to_vector())
                        {
                            if (o.is_candidate(i) && o.is_candidate(j))
                            {
                                double s = 0;
                                for (auto comp : o.candidates())
                                    s += lambda(comp);
                                J(i, j) = J(j, i) = 1 / (s * s);
                            }
                        }
                    }
                }
                return J;
            };
        };

        // special methods

        // log-likelihood function with respect to the lambdas
        std::function<double(const alex::math::column_vector&)> log_likelihood_unmasked() const
        {
            return[t_sum = _t_sum, samp = get_sample().to_vector(), comp_count = _comp_count](const alex::math::column_vector& lambda) -> double
            {
                if (comp_count != lambda.size())
                    throw std::invalid_argument("Invalid Argument");

                double result = 0;

                // sum(lambda)
                for (auto l : lambda)
                    result += lambda;

                // -sum(lambda) * sum(T)
                result *= -t_sum;

                for (const auto& o : samp)
                {
                    if (o.actual_known())
                        result += std::log(o.actual());
                }

                return result;
            };
        };

        // gradient of log-likelihood
        std::function<alex::math::column_vector(const alex::math::column_vector&)> score_unmasked() const
        {
            return[t_sum = _t_sum, samp = get_sample(), comp_count = _comp_count]
                (const alex::math::column_vector& lambda) ->alex::math::column_vector
            {
                if (comp_count != lambda.size())
                    throw std::invalid_argument("Invalid Argument");

                alex::math::column_vector result(comp_count);
                for (int i = 0; i < comp_count; ++i)
                {
                    result(i) = t_sum;
                    for (const auto& o : samp.to_vector())
                    {
                        if (o.actual_known() && o.actual() == i)
                        {
                            double s = 0;
                            for (auto comp : o.candidates())
                                s += lambda(comp);
                            result(i) += 1. / s;
                        }
                    }
                }
            };
        };

    private:
        int _comp_count;
        double _t_sum;
    };
}}}

#endif