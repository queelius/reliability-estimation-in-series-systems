#ifndef __SYSTEM_SAMPLE_GENERATOR_H__
#define __SYSTEM_SAMPLE_GENERATOR_H__

#include <iostream>
#include <set>
#include <map>
#include <unordered_map>
#include <stdexcept>
#include <vector>
#include <utility>
#include <string>
#include <algorithm>
#include <functional>
#include <boost/algorithm/string.hpp>
#include <alex/Entropy.h>
#include <alex/system_reliability_specification.h>
#include "masked_failures.h"

namespace alex { namespace statistics { namespace system_sample_generator
{
    template <class T, class E>
    std::vector<std::tuple<double, int, bool>> generate_sample(
        alex::statistics::reliability::SystemReliabilitySpecification spec,
        int sample_size,
        alex::statistics::Entropy<T, E>& entropy,
        double right_censor_time = std::numeric_limits<double>::infinity())
    {
        if (sample_size < 1)
            throw std::invalid_argument("'sample_size' Must Be Greater Than Zero");

        const auto& series_paths = spec.get_set_of_series_representation();
        const auto& nodes = spec.get_relevant_nodes();

        // vector of { node_id, inverse_cdf for node id }
        std::vector<std::pair<int, std::function<double(double)>>> ds;
        ds.reserve(nodes.size());
        for (auto node_id : nodes)
        {
            auto d = spec.get_node_distribution(node_id);
            ds.push_back(std::make_pair(node_id, d->get_inverse_cdf()));
        }

        // vector of tuples, each tuple = { life-time, actual node that caused failure, right censored true/false }
        std::vector<std::tuple<double, int, bool>> samp; samp.reserve(sample_size);
        for (int i = 0; i < sample_size; ++i)
        {
            std::unordered_map<int, double> ts;
            for (const auto& d : ds)
                ts[d.first] = d.second(entropy.get0_1());

            double max_min_time = -std::numeric_limits<double>::infinity();
            int max_min_node;

            for (const auto& series_path : series_paths)
            {
                double min_time = std::numeric_limits<double>::infinity();
                int min_node;

                for (auto node_id : series_path)
                {
                    double t = ts[node_id];

                    if (t < min_time)
                    {
                        min_time = t;
                        min_node = node_id;
                    }
                }


                if (min_time > max_min_time)
                {
                    max_min_time = min_time;
                    max_min_node = min_node;
                }
            }
            
            if (max_min_time > right_censor_time)
                samp.push_back(std::make_tuple(right_censor_time, max_min_node, true));
            else
                samp.push_back(std::make_tuple(max_min_time, max_min_node, false));
        }

        return samp;
    };

    template <class T, class E>
    alex::statistics::masked_failures::MaskedFailuresSample generate_masked_failure_sample(
        alex::statistics::reliability::SystemReliabilitySpecification spec,
        int sample_size,
        alex::statistics::Entropy<T, E>& entropy,
        std::pair<int, int> masked_failure_range,
        double right_censor_time = std::numeric_limits<double>::infinity())
    {
        if (masked_failure_range.first < masked_failure_range.second ||
            masked_failure_range.first < 1 || masked_failure_range.second < -1)
        {
            throw std::invalid_argument("[generated_masked_failure_sample] Invalid 'masked_failure_range'");
        }

        std::vector<std::tuple<double, int, bool>> samp = generate_sample(spec, sample_size, entropy, right_censor_time);
        const auto& nodes = spec.get_relevant_nodes();
        alex::statistics::masked_failures::MaskedFailuresSample fail_samp;

        for (const auto& t : samp)
        {
            int masked_failure_size = entropy.getInt(
                masked_failure_range.first,
                masked_failure_range.second == -1 ? nodes.size() : masked_failure_range.second);

            auto actual_fail_node = std::get<1>(t);

            std::set<int> candidates;
            candidates.insert(actual_fail_node);

            while (candidates.size() < masked_failure_size)
            {
                auto candidate = entropy.getInt(0, nodes.size() - 1);
                if (candidates.count(candidate) == 0)
                    candidates.insert(candidate);
            }

            const auto& f = alex::statistics::masked_failures::MaskedFailure::make(
                std::get<0>(t), std::vector<int>(candidates.begin(), candidates.end()), actual_fail_node);
            fail_samp.add(f);
        }

        return fail_samp;
    }
}}}

#endif