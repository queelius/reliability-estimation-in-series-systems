#ifndef __PENALTY_METHOD_FACTORY_H__
#define __PENALTY_METHOD_FACTORY_H__

#include <functional>
#include <memory>
#include <stdexcept>
#include <utility>
#include <alex/math.h>

namespace alex { namespace math { namespace optimization
{
    class PenaltyMethod: public std::function<double (const column_vector&)>
    {
    public:
        // assumes penalty function will be maximized; if minimized, let func = -func_to_min
        PenaltyMethod(
            std::function<double(const column_vector&)> max_func,
            int size,
            std::vector<std::function<double(const column_vector&)>> constraints,
            double penalty_factor,
            double min_penalty_coeff,
            double max_penalty_coeff) :
                _max_func(max_func),
                _size(size),
                _constraints(constraints),
                _penalty_factor(penalty_factor),
                _min_penalty_coeff(min_penalty_coeff),
                _max_penalty_coeff(max_penalty_coeff),
                _penalty_coeff(min_penalty_coeff)
        {
            if (_min_penalty_coeff > _max_penalty_coeff)
                throw std::invalid_argument("Invalid Argument");
        };

        double get_penalty_factor() const { return _penalty_factor; };
        double get_penalty_coefficient() const { return _penalty_coeff; };
        double get_max_penalty_coefficient() const { return _max_penalty_coeff; };
        double get_min_penalty_coefficient() const { return _min_penalty_coeff; };

        void reset() { _penalty_coeff = _min_penalty_coeff; };

        double operator()(const column_vector& v) const
        {
            double penalty_term = 0;
            for (auto c : _constraints)
            {
                auto c_i = c(v);
                if (c_i < 0)
                    penalty_term += c_i * c_i;
            }

            auto eval = _max_func(v) - _penalty_coeff * penalty_term;

            _penalty_coeff *= _penalty_factor;

            if (_penalty_coeff > _max_penalty_coeff)
                _penalty_coeff = _max_penalty_coeff;

            return eval;
        };

    private:
        std::function<double(const column_vector&)> _max_func;

        // constraints are such that for each c in constraints, c(v) >= 0,
        // no penalty from c(v) (not violated), otherwise penalize by p * c(v) * c(v)
        // where p is current penalty coefficient
        std::vector<std::function<double(const column_vector&)>> _constraints;

        double _penalty_factor;
        double mutable _penalty_coeff;
        double _min_penalty_coeff;
        double _max_penalty_coeff;
        int _size;
    };

    class PenaltyMethodFactory
    {
    public:
        static std::function<double(const column_vector&)> get_penalty_method_penalty_interval(
            std::function<double(const column_vector&)> max_func,
            int size,
            const std::pair<double, double>& interval,
            double min_penalty_coeff = 1e-7,
            double max_penalty_coeff = 1e+7,
            double penalty_factor = 2)
        {
            auto c = [low = interval.first, high = interval.second](const column_vector& v)
            {
                double sum = 0;
                for (auto x : v)
                {
                    if (x < low)
                        sum += std::abs(x);
                    else if (x > high)
                        sum += std::abs(x);
                }
                return -sum;
            };

            return PenaltyMethod(
                max_func,
                size,
                { c },
                penalty_factor,
                min_penalty_coeff,
                max_penalty_coeff);
        };
    };
}}}

#endif