#define _CRT_SECURE_NO_WARNINGS

/**
* @mainpage  Title of Main Page
*
*            Descriptive information placed on main page.
*            <p/> <br/>
*/

#include <functional>
#include <iostream>
#include <vector>
#include <string>
#include <alex/differentiation.h>
#include "optimization.h"
#include <dlib/optimization.h>
#include <alex/exponential_distribution.h>
#include <alex/Entropy.h>
#include <alex/math.h>
#include "series_exponential_masked_failure_likelihood.h"
#include <alex/system_reliability_specification.h>
#include "masked_failures_likelihood.h"
#include "system_sample_generator.h"
//#include "series_distribution.h"

void test_2();
std::vector<bool> test_3(int n, int m);

void main()
{
    test_2();
    /*
    std::vector<double> percent = { 0, 0, 0 };
    
    try
    {
        for (int i = 0; i < 1000; ++i)
        {
            auto cis = test_3(200, 3);
            for (int j = 0; j < cis.size(); ++j)
            {
                if (cis[j])
                    percent[j]++;
            }

            std::cout << "----" << std::endl;
            for (auto b : percent)
            {
                std::cout << b / (i + 1) << std::endl;
            }
        }
    }
    catch (const std::exception& e)
    {
        std::cout << "[ERROR] " << e.what() << std::endl;
    }
    */
};


std::vector<bool> test_3(int n, int m)
{
    const double LOWER_LAMBDA = 0;
    const double UPPER_LAMBDA = 5;

    auto entropy = alex::statistics::Entropy<>();
    auto rates = std::vector<double>();

    for (int j = 0; j < m; ++j)
    {
        rates.push_back(entropy.getReal(0.05, 2));
    }

    auto lifetime_sample = std::vector<std::pair<int, double>>();

    std::vector<alex::statistics::distribution::ExponentialDistribution> ds;
    for (auto rate : rates)
        ds.push_back(alex::statistics::distribution::ExponentialDistribution(rate));

    std::vector<std::function<double(double)>> inv_cdfs;
    for (auto d : ds)
    {
        auto params = d.get_parameters();
        for (auto param : params)
            std::cout << param.first << " -> " << param.second << std::endl;
        inv_cdfs.push_back(d.get_inverse_cdf());
    }

    for (int i = 0; i < n; ++i)
    {
        auto t_min = std::numeric_limits<double>::infinity();
        auto failed = int();
        for (auto j = 0; j < inv_cdfs.size(); ++j)
        {
            auto t = inv_cdfs[j](entropy.get0_1());
            if (t < t_min)
            {
                failed = j;
                t_min = t;
            }
        }
        lifetime_sample.push_back(std::make_pair(failed, t_min));
    }

    auto lg_L = [lifetime_sample](const alex::math::column_vector& v) -> double
    {
        auto term_1 = 0.;
        auto term_2 = 0.;
        auto term_3 = 0.;

        for (auto lam : v)
            term_2 += lam;

        for (auto l : lifetime_sample)
        {
            auto actual = l.first;
            auto t = l.second;

            term_1 += std::log(v(actual));
            term_3 += t;
        }

        if (std::isnan(term_1) || std::isnan(term_2) || std::isnan(term_3))
            throw std::exception("NaN");


        return term_1 - term_2 * term_3;
    };

    auto grad_lg_L = [lifetime_sample](const alex::math::column_vector& v)
    {
        auto n = lifetime_sample.size();
        alex::math::column_vector grad(v.size());

        auto sum = 0.;
        for (auto& x : grad)
            x = 0.;

        for (auto l : lifetime_sample)
        {
            auto actual = l.first;
            auto t = l.second;

            sum += t;
            grad(actual) += 1. / v(actual);
        }

        for (auto& x : grad)
            x -= sum;

        return grad;
    };

    auto sum = 0.;
    auto counts = std::vector<int>(ds.size());
    for (auto& count : counts)
        count = 0;

    for (auto l : lifetime_sample)
    {
        auto actual = l.first;
        auto t = l.second;

        ++counts[actual];
        sum += t;
    }

    //std::cout << "exact MLE solution:" << std::endl;
    //auto exact_mle = alex::math::column_vector(ds.size());
    //for (int i = 0; i < counts.size(); ++i)
    //{
    //    exact_mle(i) = counts[i] / sum;
    //    std::cout << exact_mle(i) << std::endl;
    //}
    //std::cout << "value at this mle: " << lg_L(exact_mle) << std::endl;
    //std::cout << "---" << std::endl;

    const double ALPHA = 1e-3;
    const double EPS = 1e-7;
    auto interval = std::make_pair(LOWER_LAMBDA, UPPER_LAMBDA);

    //std::cout << "---" << std::endl;
    auto best = alex::math::optimization::find_max(lg_L, ds.size(), entropy, interval, ALPHA, EPS);
    //std::cout << "find_max solution:\n";
    //std::cout << best.second << std::endl;
    //std::cout << "lgL evaluated at this point is: " << best.first << std::endl;
    //std::cout << "---" << std::endl;

    auto hess = alex::math::differentiation::hessian([lg_L](const alex::math::column_vector& v) { return -lg_L(v); }, ds.size());
    auto cov = dlib::pinv(hess(best.second));

    std::vector<bool> results;
    for (int i = 0; i < ds.size(); ++i)
    {
        double ci = std::sqrt(cov(i, i));
        auto p = std::make_pair(best.second(i) - 1.96 * ci, best.second(i) + 1.96 * ci);

        if (rates[i] >= p.first && rates[i] <= p.second)
            results.push_back(true);
        else
            results.push_back(false);
    }

    return results;
}

void test_2()
{
    try
    {
        const double ALPHA = 1e-3;
        const double EPS = 1e-7;
        auto interval = std::make_pair(0, 5);

        auto factory = alex::statistics::distribution::DistributionFactory();
        auto spec = alex::statistics::reliability::SystemReliabilitySpecification(factory);
        spec.set_description("series 3-out-of-3 system");
        spec.set_series_structure(3);
        spec.set_component_description(0, "EXP(.5)");
        spec.set_component_description(1, "EXP(1)");
        spec.set_component_description(2, "EXP(.75)");
        spec.set_component_distribution(0, "exponential", { std::make_pair("rate", .5) });
        spec.set_component_distribution(1, "exponential", { std::make_pair("rate", 1) });
        spec.set_component_distribution(2, "exponential", { std::make_pair("rate", .75) });

        alex::statistics::Entropy<> entropy;
        auto masked_samp = alex::statistics::system_sample_generator::generate_masked_failure_sample(
            spec, 20, entropy, std::make_pair(2, 2));

        masked_samp.write_cvs("masked_sample.cvs",
            "this sample is for a series 3-out-of-3 system with masked failure size 2");

        std::ofstream out("series_exponential.json");
        out << picojson::value(spec.get_json()) << std::endl;

        auto sys = alex::statistics::masked_failures::ExponentialSeriesMaskedFailuresLikelihood(3);
        sys.load_sample(masked_samp);


        //auto mle = alex::math::optimization::find_max(sys.log_likelihood(), sys.score(), 3, entropy, interval, ALPHA, EPS);
        auto mle = sys.find_mle();

        std::cout << mle.second << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cout << e.what() << std::endl;
    }
}