#ifndef _MASKED_FAILURE_LIKELIHOOD_H__
#define _MASKED_FAILURE_LIKELIHOOD_H__

#include <algorithm>
#include <numeric>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <functional>
#include <alex/csv.h>
#include <dlib/matrix.h>
#include <dlib/optimization.h>
#include <alex/Entropy.h>
#include <alex/differentiation.h>
#include <alex/distribution.h>
#include <alex/math.h>
#include "masked_failures.h"
#include "optimization.h"

namespace alex { namespace statistics { namespace masked_failures
{
    typedef dlib::matrix<double> info_matrix;

    class MaskedFailuresLikelihood
    {
    public:
        MaskedFailuresLikelihood() {};

        virtual void load_sample(const MaskedFailuresSample& sample)
        {
            _sample = sample;
        };

        // likelihood function
        virtual std::function<double(const alex::math::column_vector&)> likelihood() const
        {
            return[l = log_likelihood()](const alex::math::column_vector& params) { return std::exp(l(params)); };
        }

        // log-likelihood function
        virtual std::function<double(const alex::math::column_vector&)> log_likelihood() const = 0;

        // score is equivalent to the gradient of the log-likelihood
        virtual std::function<alex::math::column_vector(const alex::math::column_vector&)> score() const
        {
            return alex::math::differentiation::gradient(log_likelihood(), parameter_count());
        };

        // find the maximum likleihood estimate for the parameters of the distribution
        // given the sample of masked failures and an initial parameter value
        virtual std::pair<double, alex::math::column_vector> find_mle() const = 0;

        virtual int parameter_count() const = 0;

        virtual std::function<info_matrix(const alex::math::column_vector&)> observed_info() const
        {
            return alex::math::differentiation::hessian([loglike = log_likelihood()](
                const alex::math::column_vector& v) { return -loglike(v); }, parameter_count());
        };

        virtual std::vector<std::pair<double, double>> fisher_confidence_interval(const alex::math::column_vector& mle, double alpha)
        {
            auto info = observed_info();
            auto cov = dlib::pinv(info(mle));

            std::vector<std::pair<double, double>> ci;
            for (int i = 0; i < parameter_count(); ++i)
            {
                double se = std::sqrt(cov(i, i));
                ci.push_back(std::make_pair(mle(i) - 1.96 * se, mle(i) + 1.96 * se));
            }

            return ci;
        };

        // virtual std::vector<std::pair<double, double>> bootstrap_confidence_interval(double alpha) = 0;

        virtual const MaskedFailuresSample& get_sample() const { return _sample; };

        //virtual DistributionPtr get_distribution() = 0;

        //virtual std::vector<DistributionPtr> get_distributions() const = 0;

    private:
        MaskedFailuresSample _sample;
    };
}}}

#endif