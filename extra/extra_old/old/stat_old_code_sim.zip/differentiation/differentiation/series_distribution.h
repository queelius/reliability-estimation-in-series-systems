
#ifndef _SERIES_DISTRIBUTION_H__
#define _SERIES_DISTRIBUTION_H__

#include <algorithm>
#include <stdexcept>
#include <vector>
#include <functional>
#include <alex/distribution.h>
#include <alex/Entropy.h>
#include <alex/EmpiricalDistribution.h>
#include <alex/math.h>

namespace alex { namespace statistics { namespace distribution
{
    class SeriesDistribution : public alex::statistics::distribution::Distribution
    {
    public:
        SeriesDistribution(const std::vector<DistributionPtr>& dists) : _dists(dists) {};

        SeriesDistribution() {};

        void add_distribution(DistributionPtr d) { _dists.push_back(d); };

        int size() const { return static_cast<int>(_dists.size()); };

        std::vector<DistributionPtr> get_distributions() const { return _dists; };

        // functors
        std::function<double(double)> get_pdf() const
        {
            std::vector<std::function<double(double)>> pdfs;
            std::vector<std::function<double(double)>> survivals;
            pdfs.reserve(_dists.size());
            survivals.reserve(_dists.size());

            for (auto d : _dists)
            {
                pdfs.push_back(d->get_pdf());
                survivals.push_back(d->get_survival());
            }

            return[size = pdfs.size(), pdfs = std::move(pdfs), survivals = std::move(survivals)](double t)
            {
                double result = 0;
                for (int i = 0; i < size; ++i)
                {
                    double term = pdfs[i](t);
                    for (int j = 0; j < size; ++j)
                    {
                        if (i == j)
                            continue;
                        term *= survivals[j](t);
                    }
                    result += term;
                }
                return result;
            };
        };

        std::function<double(double)> get_cdf() const
        {
            return[survival = get_survival()](double t)
            {
                return 1 - survival(t);
            };
        };

        std::function<double(double)> get_survival() const
        {
            std::vector<std::function<double(double)>> survivals;
            survivals.reserve(_dists.size());

            for (const auto& d : _dists)
                survivals.push_back(d->get_survival());

            return[size = survivals.size(), survivals = std::move(survivals)](double t)
            {
                double result = 1;
                for (const auto& surv : survivals)
                    result *= surv(t);
                return result;
            };
        };

        std::function<double(double)> get_hazard() const
        {
            return[pdf = get_pdf(), srv = get_survival()](double t)
            {
                return pdf(t) / srv(t);
            };
        };

        std::function<double(double)> get_inverse_cdf() const
        {
            // generate sample of n t values [T = min(T_1, ..., T_m)]
            // p = F[t] is proportion of samples less than t
            // t = F^-1(p), t is such that p = #(T <= t) / #(T)

            const auto N = 100000;
            auto entropy = alex::statistics::Entropy<>();
            auto samp = std::vector<double>();
            samp.reserve(N);
            std::vector<std::function<double(double)>> Q;

            for (auto d : _dists)
                Q.push_back(d->get_inverse_cdf());

            for (auto i = 0; i < N; ++i)
            {
                auto p = entropy.get0_1();
                auto min_t = std::numeric_limits<double>::infinity();
                for (auto q : Q)
                    min_t = std::min(min_t, q(entropy.get0_1()));
                samp.push_back(min_t);
            }

            auto Fn = alex::statistics::distributions::
                EmpiricalDistribution<double, double>::fromFrequency(samp.begin(), samp.end());

            return[Fn](double p)
            {
                return Fn.inverseCdf(p);
            };
        };

        // accessors
        std::string get_family() const { return "general_series"; };

        std::pair<double, double> get_domain() const
        {
            std::pair<double, double> dom;
            for (auto d : _dists)
            {
                const auto& dom_d = d->get_domain();
                dom.first = std::min(dom_d.first, dom.first);
                dom.second = std::max(dom_d.second, dom.second);
            }
            return dom;
        };

        int parameter_count() const
        {
            int count = 0;
            for (auto d : _dists)
                count += d->parameter_count();
            return count;
        };

        ParameterList get_parameters() const
        {
            ParameterList params;
            for (auto d : _dists)
            {
                auto p = d->get_parameters();
                params.insert(params.end(), p.begin(), p.end());
            }
            return params;
        }

        // mutators
        void set_parameter(const alex::math::column_vector& params)
        {
            if (params.size() != parameter_count())
                throw std::invalid_argument("Invalid Parameters");

            for (int i = 0; i < parameter_count(); ++i)
                set_parameter(i, params(i));
        }

        void set_parameter(int idx, double value)
        {
            auto i = 0;
            for (auto d : _dists)
            {
                if (i + d->parameter_count() < idx)
                    i += d->parameter_count();
                else
                {
                    d->set_parameter(idx - i, value);
                    break;
                }
            }
        }

        void set_parameters(const ParameterList& params)
        {
            throw std::exception("Not Implemented");
        };

    private:
        std::vector<DistributionPtr> _dists;
    };
}}}

#endif