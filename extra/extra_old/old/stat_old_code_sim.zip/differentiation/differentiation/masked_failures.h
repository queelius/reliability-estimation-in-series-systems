#ifndef __MASKED_FAILURES_H__
#define __MASKED_FAILURES_H__

#include <algorithm>
#include <sstream>
#include <fstream>
#include <numeric>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <alex/csv.h>
#include <boost/algorithm/string.hpp>

namespace alex { namespace statistics { namespace masked_failures
{
    class MaskedFailure
    {
    public:
        static const int NOT_KNOWN = -1;

        static MaskedFailure make_right_censored(double t) { return MaskedFailure(t, std::vector<int>(), NOT_KNOWN); };
        static MaskedFailure make(double t, std::vector<int> candidates, int actual = NOT_KNOWN) { return MaskedFailure(t, candidates, actual); };

        bool right_censored() const { return _candidates.empty(); };
        double time() const { return _t; };
        int actual() const { return _actual_node; };
        bool is_candidate(int node) const { return std::binary_search(_candidates.begin(), _candidates.end(), node); };
        int candidate_count() const { return _candidates.size(); };
        std::vector<int> candidates() const { return _candidates; };
        bool actual_known() const { return _actual_node > NOT_KNOWN; };

    private:
        MaskedFailure(double t, std::vector<int> candidates, int actual) : _t(t), _actual_node(actual)
        {
            if (actual < NOT_KNOWN)
                throw std::invalid_argument("[MaskedFailure::constructor] Invalid Argument: actual < -1");

            std::sort(candidates.begin(), candidates.end());
            candidates.erase(std::unique(
                candidates.begin(), candidates.end()), candidates.end());

            if (actual != NOT_KNOWN && !std::binary_search(candidates.begin(), candidates.end(), actual))              
                throw std::invalid_argument("[MaskedFailure::constructor] actual Not A Candidate");

            _candidates = std::move(candidates);
        };

        double _t;                      // failure time;

        int _actual_node;               // actual node that caused the system failure
                                        // _actual_node = NOT_KNOWN if actual node is not known

        std::vector<int> _candidates;   // one of these nodes caused the failure
    };

    class MaskedFailuresSample
    {
    public:
        void read_cvs(const std::string& filename)
        {
            int row = 1;
            double t;
            std::string candidate_str;
            int right_censored;
            int actual_node = -1;

            ::io::CSVReader<
                4,
                ::io::trim_chars<' ', '\t'>,
                ::io::no_quote_escape<','>,
                ::io::throw_on_overflow,
                ::io::single_and_empty_line_comment<'#'>
            > csv(filename);

            csv.read_header(::io::ignore_extra_column, "time", "candidates", "actual_node", "right_censored");
            while (true)
            {
                try
                {
                    if (!csv.read_row(t, candidate_str, actual_node, right_censored))
                        break;

                    std::stringstream ss(candidate_str);
                    std::vector<int> candidates;
                    int candidate;

                    while (ss)
                    {
                        if (isdigit(ss.peek()))
                        {
                            ss >> candidate;
                            candidates.push_back(candidate);
                        }
                        else
                            ss.ignore(1);
                    }

                    if (right_censored != 0 && !candidates.empty())
                    {
                        std::cerr << "[WARNING] ignoring non-empty candidate list column "
                            << "in row " << row << " since its right-censored column is true\n";
                        add(MaskedFailure::make(t, std::vector<int>(), actual_node));
                    }
                    else if (right_censored == 0 && candidates.empty())
                        std::cerr << "[WARNING] ignoring row " << row << " since it has an "
                        << "empty candidate list column and its right-censored column is false\n";
                    else
                        add(MaskedFailure::make(t, candidates, actual_node));
                    ++row;
                }
                catch (const std::exception& e)
                {
                    std::cerr << "[WARNING] row " << row << " generated exception: " << e.what() << std::endl;
                }
                catch (...)
                {
                    std::cerr << "[ERROR] unknown error" << std::endl;
                }
            }
        };

        void write_cvs(const std::string& filename, const std::string& comment = "")
        {
            std::ofstream out(filename);
            if (!out)
            {
                std::stringstream ss;
                ss << "[MaskedFailureSample::write_cvs] Could Not Open File '" << filename << "'";
                throw std::exception(ss.str().c_str());
            }

            if (!comment.empty())
            {
                std::vector<std::string> comment_lines;
                boost::split(comment_lines, comment, boost::is_any_of("\n"));
                for (const auto& line : comment_lines)
                    out << "# " << line << std::endl;
            }

            out << "time,actual_node,right_censored,candidates\n";
            for (const auto& row : _sample)
            {
                out << row.time() << ',';
                out << row.actual() << ',';
                out << row.right_censored() << ',';

                bool first = true;
                for (auto candidate : row.candidates())
                {
                    if (first)
                    {
                        out << candidate;
                        first = false;
                    }
                    else
                        out << ' ' << candidate;
                }
                out << '\n';
            }
        };

        void add(const MaskedFailure& masked_failure) { _sample.push_back(masked_failure); };

        void add(const std::vector<MaskedFailure>& sample) { _sample.insert(_sample.begin(), sample.begin(), sample.end()); };

        void set(const std::vector<MaskedFailure>& sample) { _sample = sample; };

        int candidate_count(int candidate)
        {
            int count = 0;
            for (const auto& o : _sample) count += static_cast<int>(o.is_candidate(candidate));
            return count;
        };

        int size() const { return (int)_sample.size(); }

        double sum_time() const
        {
            double sum = 0;
            for (const auto& o : _sample) sum += o.time();
            return sum;
        };

        double mean_time() const { return sum_time() / size(); };

        void remove_right_censored()
        {
            std::remove_if(_sample.begin(), _sample.end(), [](const MaskedFailure& f)
            {
                return f.right_censored();
            });
        };

        void remove_actual(int actual)
        {
            std::remove_if(_sample.begin(), _sample.end(), [actual](const MaskedFailure& f)
            {
                return f.actual() == actual;
            });
        };

        void remove_candidate_counts_less_than(int count)
        {
            std::remove_if(_sample.begin(), _sample.end(), [count](const MaskedFailure& f)
            {
                return f.candidate_count() < count;
            });
        };

        void remove_candidate_counts_greater_than(int count)
        {
            std::remove_if(_sample.begin(), _sample.end(), [count](const MaskedFailure& f)
            {
                return f.candidate_count() > count;
            });
        };

        void remove_time_less_than(double t)
        {
            std::remove_if(_sample.begin(), _sample.end(), [t](const MaskedFailure& f)
            {
                return f.time() < t;
            });
        };

        void remove_time_greater_than(double t)
        {
            std::remove_if(_sample.begin(), _sample.end(), [t](const MaskedFailure& f)
            {
                return f.time() > t;
            });
        };

        void remove_candidate(int node)
        {
            std::remove_if(_sample.begin(), _sample.end(), [node](const MaskedFailure& f)
            {
                return f.is_candidate(node);
            });
        };

        void sort_by_time()
        {
            std::sort(_sample.begin(), _sample.end(),
                [](const MaskedFailure& x1, const MaskedFailure& x2)
            {
                return x1.time() < x2.time();
            });
        };

        void remove(int idx) { _sample.erase(_sample.begin() + idx); };

        void remove_all() { _sample.clear();  };

        std::vector<MaskedFailure> to_vector() const { return _sample; };

    private:
        std::vector<MaskedFailure> _sample;
    };
}}}

#endif