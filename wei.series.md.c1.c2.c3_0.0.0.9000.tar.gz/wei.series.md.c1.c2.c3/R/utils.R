#' Newton-Raphson method
#' 
#' @param fn function to be optimized
#' @param x0 initial guess
#' @param gr gradient function
#' @param hess hessian function
#' @param tol tolerance
#' @param sup support function
#' @param lr learning rate
#' @param parscale parameter scaling
#' @param debug debug flag
#' @param REPORT report frequency
#' @param r line search decay
#' @param maxit maximum number of iterations
#' @return list of converged, parameter, number of iterations, hessian, and value
#' @importFrom MASS ginv
#' @export
newton_raphson <- function(
    fn,
    x0,
    gr,
    hess,
    parscale = 1,
    tol = 1e-10,
    sup = function(x) TRUE,
    lr = 1,
    debug = FALSE,
    REPORT = 100L,
    r = 0.5,
    maxit = 1000L) {


    scaled_sup <- function(x) sup(x * parscale)
    scaled_fn <- function(x) fn(x * parscale)
    scaled_gr <- function(x) gr(x * parscale) * parscale
    scaled_hess <- function(x) {
        H <- hess(x * parscale)
        for (i in seq_along(parscale)) {
            for (j in seq_along(parscale)) {
                H[i, j] <- H[i, j] * parscale[i] * parscale[j]
            }
        }
        H
    }

    x0 <- x0 / parscale
    iter <- 1L
    converged <- FALSE
    repeat {
        y <- scaled_fn(x0)
        d <- ginv(scaled_hess(x0)) %*% scaled_gr(x0)
        if (max(abs(d)) < tol) {
            converged <- TRUE
            break
        }

        if (debug && iter %% REPORT == 0) {
            cat("iter = ", iter, ", x0 = ", x0, ", f(x0) = ", y, "\n")
        }
        eta <- lr
        repeat {
            x1 <- x0 - eta * d
            if (scaled_sup(x1) && scaled_fn(x1) >= y) {
                break
            }
            eta <- r * eta
        }

        if (iter == maxit) {
            break
        }

        x0 <- x1
        iter <- iter + 1L
    }
    x1 <- x1 * parscale
    list(converged = converged, par = x1, iter = iter, hessian = hess(x1),
        value = fn(x1))
}

#' Gradient ascent method
#' 
#' @param fn function to be optimized
#' @param x0 initial guess
#' @param gr gradient function
#' @param sup support function
#' @param lr learning rate
#' @param debug debug flag
#' @param REPORT report frequency
#' @param r line search decay
#' @param maxit maximum number of iterations
#' @return list of converged, parameter, and number of iterations
#' @export
grad_ascent <- function(
    fn,
    x0,
    gr,
    sup = function(x) TRUE,
    lr = 1,
    debug = FALSE,
    REPORT = 100L,
    r = 0.8,
    maxit = 100L) {

    iter <- 1L
    repeat {
        y <- fn(x0)
        gx <- gr(x0)
        if (debug && iter %% REPORT == 0) {
            cat("iter = ", iter, ", x0 = ", x0, ", f(x0) = ", y, "\n")
        }
        eta <- lr
        repeat {
            iter <- iter + 1L
            x1 <- x0 + eta * gx
            if (sup(x1) && fn(x1) > y) {
                break
            }
            eta <- r * eta
        }

        if (iter > maxit) {
            break
        }

        x0 <- x1
    }
    return(list(param = x1, iter = iter))
}

